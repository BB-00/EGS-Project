import json
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import json


with open('.secret/key_db.json') as f:
    x = json.load(f)
    engine = create_engine(x['url'])

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)