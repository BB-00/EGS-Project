from sqlalchemy import Column, Integer, Float, String, Boolean,Date, ForeignKey
from sqlalchemy.orm import relationship

from database.base_class import Base

class Transactions(Base):
    transactionID = Column(Integer, primary_key=True, autoincrement=True)
    amount = Column(Float, )
