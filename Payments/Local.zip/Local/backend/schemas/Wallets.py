from typing import Optional
from pydantic import BaseModel

class WalletCreate(BaseModel):
    walletID: int
    username: str
    balance: float

class WalletShow(BaseModel):
    walletID: int
    username: str
    balance: float
