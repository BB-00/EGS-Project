import datetime
from typing import Optional
from pydantic import BaseModel

class TransactionCreate(BaseModel):
    transactionID: int
    amount: float
    methodID: int
    date: datetime.datetime
    walletID: int

class TransactionShow(BaseModel):
    transactionID: int
    amount: float
    methodID: int
    date: datetime.datetime
    walletID: int