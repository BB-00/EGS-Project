from fastapi import APIRouter
from fastapi import Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from typing import Union


templates = Jinja2Templates(directory="templates")
general_pages_router = APIRouter()


@general_pages_router.get("/")
async def home(request: Request):
	return templates.TemplateResponse("general_pages/homepage.html",{"request":request})


# @general_pages_router.post("/addfunds")
# def add_funds_post():
#     return 'Do some magic!'

# @general_pages_router.get("/transaction")
# async def transaction_get(offset: Union[int,None] = None, limit: Union[int,None] = None, transaction_id: Union[int,None] = None, amount: Union[int,None] = None, _date: Union[datetime,None] = None):
#     # cur.execute("SELECT * FROM Transactions")
#     # x = cur.next
#     return x

# @general_pages_router.post("/transaction")
# def transaction_post():
#     return 'do some magic'

# @general_pages_router.get("/transaction/{transaction_id}")
# def transaction_transaction_id_get(transaction_id: int):
#     return 'do some magic!'

# @general_pages_router.post("/transaction/{transaction_id}/refund")
# def transaction_transaction_id_refund_post(transaction_id: int):
#     return 'do some magic!'

# @general_pages_router.get("/wallet")
# def wallet_get():
#     return 'do some magic!'